set module parameters with below command:

#insmod demodev.ko dolphin=5 demodev_str="hello,world"