#!/bin/bash

module="scull"
file="$module".ko
major=0

if [[ -e $file ]]
then
	echo "1. sudo insmod $module"
	/sbin/insmod ./$file || exit 1
	echo "2. get major num form /proc/devices"
	major=$(awk "\$2==\"$module\"{print \$1}" /proc/devices)
	echo "3. mknod /dev/$module"
	/bin/mknod /dev/$module c $major 0
	echo "4. chmod 666 /dev/$module"
	chmod 666 /dev/$module
	echo "ls -l /dev/$module"
	ls -l /dev/$module
else 
	echo $file "not exist"
fi
