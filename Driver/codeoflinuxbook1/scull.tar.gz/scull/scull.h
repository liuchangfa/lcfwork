#ifndef _SCULL_H
#define _SCULL_H

#define SCULL_MAJOR 0
#define SCULL_BUFFER_SIZE 1024

struct scull_dev {
	char * data;
	unsigned int size;
	struct semaphore sem;
	struct cdev cdev;
};

#endif

