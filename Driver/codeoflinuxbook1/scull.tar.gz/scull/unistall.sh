#!/bin/bash

module="scull"
echo "1. rm /dev/$module"
rm /dev/$module
echo "2. rmmod $module"
/sbin/rmmod $module
