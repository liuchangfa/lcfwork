#include <linux/init.h>
#include <linux/module.h>
#include <linux/types.h>
#include <linux/kdev_t.h>
#include <linux/slab.h>
#include <linux/kernel.h>
#include <linux/cdev.h>
#include <asm/uaccess.h>
#include <linux/fs.h>
#include <linux/semaphore.h>
#include "scull.h"

int scull_major = SCULL_MAJOR;
int scull_minor = 0;

module_param(scull_major, int, S_IRUGO);
module_param(scull_minor, int, S_IRUGO);

struct scull_dev * pscull_dev;

int scull_trim(struct scull_dev *dev)
{
	if (dev)
	{
		if (dev->data)
			kfree(dev->data);
		dev->data = NULL;
		dev->size = 0;
	}
}

int scull_open(struct inode * inode, struct file *filp)
{
	struct scull_dev * pdev;
	pdev = container_of(inode->i_cdev,struct scull_dev,cdev);
	filp->private_data = pdev;

	if ((filp->f_flags & O_ACCMODE) == O_WRONLY)
	{
		if (down_interruptible(&pdev->sem))
			return -ERESTARTSYS;
		scull_trim(pdev);
		up(&pdev->sem);
	}

	return 0;
}

int scull_release(struct inode *inode,struct file *filp)
{
	return 0;
}

ssize_t scull_read(struct file *filp,char __user *buf
					, size_t count, loff_t *f_pos)
{
	struct scull_dev * dev = filp->private_data;
	int ret = 0;

	if (down_interruptible(&dev->sem))
		return -ERESTARTSYS;

	if (*f_pos >= dev->size)
		goto out;
	if (*f_pos + count > dev->size)
		count = dev->size - *f_pos;
	
	if (dev->data == NULL)
		goto out;

	if (copy_to_user(buf,dev->data + *f_pos,count))
	{
		ret = -EFAULT;
		goto out;
	}

	*f_pos += count;
	ret = count;
out:
	up(&dev->sem);
	return ret;
}

ssize_t scull_write(struct file *filp,const char __user *buf
					, size_t count, loff_t * f_pos)
{
	struct scull_dev *dev = filp->private_data;
	int ret = -ENOMEM;

	if (down_interruptible(&dev->sem)) 
		return -ERESTARTSYS;

	if (dev->data == NULL)
	{
		dev->data = kmalloc(SCULL_BUFFER_SIZE,GFP_KERNEL);
		if (dev->data == NULL)
			goto out;
		memset(dev->data,0,SCULL_BUFFER_SIZE);
	}

	if (*f_pos >= SCULL_BUFFER_SIZE)
		goto out;
	if (*f_pos + count > SCULL_BUFFER_SIZE)
		count = SCULL_BUFFER_SIZE - *f_pos;
	
	if (copy_from_user(dev->data + *f_pos,buf,count))
	{
		ret = -EFAULT;
		goto out;
	}
	*f_pos += count;
	
	if (dev->size < *f_pos)
		dev->size = *f_pos;

	ret = count;
out:
	up(&dev->sem);
	return ret;
}

loff_t scull_lseek(struct file *filp,loff_t offset,int orig)
{
	struct scull_dev *dev = filp->private_data;
	loff_t ret;

	switch(orig) {
		case 0:
			ret = offset;
			break;
		case 1:
			ret = filp->f_pos + offset;
			break;
		case 2:
			ret = dev->size + offset;
			break;
		default:
			return -EINVAL;
	}

	if (ret < 0) 
		return -EINVAL;
	filp->f_pos = ret;
	return ret;
}

struct file_operations scull_fops = {
	.owner = THIS_MODULE,
	.read = scull_read,
	.write = scull_write,
	.open = scull_open,
	.release = scull_release,
	.llseek = scull_lseek,
};

static int __init scull_init(void)
{
	int ret;
	dev_t dev;

	if (scull_major)
	{
		dev = MKDEV(scull_major,scull_minor);
		ret = register_chrdev_region(dev,1,"scull");
	} else {
		ret = alloc_chrdev_region(&dev,0,1,"scull");
		scull_major = MAJOR(dev);
	}
	
	if (ret < 0) {
		printk(KERN_WARNING"scull: can't get major: %d",scull_major);
		return ret;
	}
	
	pscull_dev = kmalloc(sizeof(struct scull_dev),GFP_KERNEL);
	if (pscull_dev == NULL) {
		ret = -ENOMEM;
		goto fail;
	}
	memset(pscull_dev,0,sizeof(struct scull_dev));
	sema_init(&pscull_dev->sem,1);
	
	cdev_init(&pscull_dev->cdev,&scull_fops);
	pscull_dev->cdev.owner = THIS_MODULE;
	
	ret = cdev_add(&pscull_dev->cdev,dev,1);
	if (ret) {
		printk(KERN_NOTICE"Error %d adding scull",ret);
	}

	return 0;

fail:
	unregister_chrdev_region(dev,1);
	return ret;
}

static void __exit scull_exit(void)
{
	dev_t dev = MKDEV(scull_major,scull_minor);

	if (pscull_dev)
	{
		scull_trim(pscull_dev);
		cdev_del(&pscull_dev->cdev);
		pscull_dev = NULL;
	}

	unregister_chrdev_region(dev,1);
}

module_init(scull_init);
module_exit(scull_exit);

MODULE_AUTHOR("dusong");
MODULE_LICENSE("GPL");
