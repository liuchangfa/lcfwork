#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(void)
{
	FILE *fp;
	char buf[128] = "123";

	fp = fopen("/dev/scull","w+");
	if (!fp) {
		printf("/dev/scull open error\n");
		exit(1);
	}
	printf("/dev/scull open success\n");
	fputs("Hello,world",fp);
	fseek(fp,0,SEEK_SET);
	fgets(buf,128,fp);
	puts(buf);

	memset(buf,0,128);
	fputs("Hi,every one",fp);
	fseek(fp,0,SEEK_SET);
	fgets(buf,128,fp);
	puts(buf);

	memset(buf,0,128);
	fgets(buf,128,fp);
	puts(buf);

	fclose(fp);
	return 0;
}
