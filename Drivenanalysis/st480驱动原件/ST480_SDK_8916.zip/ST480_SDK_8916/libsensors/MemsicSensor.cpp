/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#define LOG_NDDEBUG 0

#include <fcntl.h>
#include <errno.h>
#include <math.h>
#include <poll.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/select.h>
#include <dlfcn.h>

#include <cutils/log.h>

#include "MemsicSensor.h"


/*****************************************************************************/

MemsicSensor::MemsicSensor()
: SensorBase(NULL, ECS_DATA_DEV_NAME),
      mEnabled(0),
      mPendingMask(0),
      mInputReader(32)
{
    /* Open the library before opening the input device.  The library
     * creates a uinput device.
     */
    dev_name = ECS_CTRL_DEV_NAME;

    open_device();
    ALOGE("dev_fd = %d data_fd = %d", dev_fd, data_fd);

    memset(mPendingEvents, 0, sizeof(mPendingEvents));

    mPendingEvents[Accelerometer].version = sizeof(sensors_event_t);
    mPendingEvents[Accelerometer].sensor = ID_A;
    mPendingEvents[Accelerometer].type = SENSORS_ACCELERATION_HANDLE;
    mPendingEvents[Accelerometer].acceleration.status = SENSOR_STATUS_ACCURACY_HIGH;

    mPendingEvents[MagneticField].version = sizeof(sensors_event_t);
    mPendingEvents[MagneticField].sensor = ID_M;
    mPendingEvents[MagneticField].type = SENSORS_MAGNETIC_FIELD_HANDLE;
    mPendingEvents[MagneticField].magnetic.status = SENSOR_STATUS_ACCURACY_HIGH;

    mPendingEvents[Orientation  ].version = sizeof(sensors_event_t);
    mPendingEvents[Orientation  ].sensor = ID_O;
    mPendingEvents[Orientation  ].type = SENSORS_ORIENTATION_HANDLE;
    mPendingEvents[Orientation  ].orientation.status = SENSOR_STATUS_ACCURACY_HIGH;

    // read the actual value of all sensors if they're enabled already
    struct input_absinfo absinfo;
    short flags = 0;

    if (data_fd < 0 || dev_fd < 0)
        return;
    if (!ioctl(dev_fd, ECOMPASS_IOC_GET_MFLAG, &flags))  {
        mEnabled |= 1<<MagneticField;
        if (!ioctl(data_fd, EVIOCGABS(EVENT_TYPE_MAGV_X), &absinfo)) {
            mPendingEvents[MagneticField].magnetic.x = absinfo.value * CONVERT_M;
        }
        if (!ioctl(data_fd, EVIOCGABS(EVENT_TYPE_MAGV_Y), &absinfo)) {
            mPendingEvents[MagneticField].magnetic.y = absinfo.value * CONVERT_M;
        }
        if (!ioctl(data_fd, EVIOCGABS(EVENT_TYPE_MAGV_Z), &absinfo)) {
            mPendingEvents[MagneticField].magnetic.z = absinfo.value * CONVERT_M;
        }
    }
    if (!ioctl(dev_fd, ECOMPASS_IOC_GET_OFLAG, &flags))  {
        mEnabled |= 1<<Orientation;
        if (!ioctl(data_fd, EVIOCGABS(EVENT_TYPE_YAW), &absinfo)) {
            mPendingEvents[Orientation].orientation.azimuth = absinfo.value;
        }
        if (!ioctl(data_fd, EVIOCGABS(EVENT_TYPE_PITCH), &absinfo)) {
            mPendingEvents[Orientation].orientation.pitch = absinfo.value;
        }
        if (!ioctl(data_fd, EVIOCGABS(EVENT_TYPE_ROLL), &absinfo)) {
            mPendingEvents[Orientation].orientation.roll = -absinfo.value;
        }
        if (!ioctl(data_fd, EVIOCGABS(EVENT_TYPE_ORIENT_STATUS), &absinfo)) {
            mPendingEvents[Orientation].orientation.status = uint8_t(absinfo.value & SENSOR_STATE_MASK);
        }
    }
    ALOGE("Memsic Sensor constructor done");
}

MemsicSensor::~MemsicSensor()
{
}

int MemsicSensor::enable(int32_t handle, int en)
{
    int what = -1;

    switch (handle) {
        case ID_M:
			what = MagneticField;
			break;
        case ID_O:
			what = Orientation;
			break;
    }

    if (uint32_t(what) >= numSensors)
        return -EINVAL;

    int newState  = en ? 1 : 0;
    int err = 0;

    if ((uint32_t(newState)<<what) != (mEnabled & (1<<what))) {
        uint32_t sensor_type=0;
        switch (what) {
	    /*case Accelerometer: 
			    sensor_type = ECOMPASS_IOC_SET_AFLAG;  
				break;*/
            case MagneticField:
				sensor_type = SENSORS_MAGNETIC_FIELD_HANDLE;
				break;
            case Orientation:
				sensor_type = SENSORS_ORIENTATION_HANDLE;
				break;
        }
        short flags = newState;
        
        err = enable_disable_sensor(sensor_type, en);

        ALOGE("Change sensor state (%s)", strerror(-err));
        if (!err) {
            mEnabled &= ~(1<<what);
            mEnabled |= (uint32_t(flags)<<what);
        }
    }
    ALOGE("MemsicSensor::enable done");
    return err;
}

int MemsicSensor::enable_disable_sensor(uint32_t sensor_type, int enable)
{
    short flags = enable;
	int err = 0;
    ALOGE("MemsicSensor::enable_disable_sensor");
    switch (sensor_type) {
        case SENSORS_ACCELERATION_HANDLE: 
           /* if(ioctl(dev_fd, ECOMPASS_IOC_SET_AFLAG, &flags) < 0) {
                return -ENODEV;
            }
	    */
            break;
        case SENSORS_MAGNETIC_FIELD_HANDLE:
			err = ioctl(dev_fd, ECOMPASS_IOC_SET_MFLAG, &flags);
			ALOGE("ioctl ECOMPASS_IOC_SET_MFLAG return: %d", err);
            if (err < 0) {  
                return -ENODEV;
            }
            break;
        case SENSORS_ORIENTATION_HANDLE:
			err = ioctl(dev_fd, ECOMPASS_IOC_SET_OFLAG, &flags);
			ALOGE("ioctl ECOMPASS_IOC_SET_OFLAG return: %d", err);
            if (err < 0) {  
                return -ENODEV;
            }
            break;
        default:
            break;
    }
        
    return 0;
}

int MemsicSensor::setDelay(int32_t handle, int64_t ns)
{
    uint32_t sensor_type = 0;

    ALOGE("MemsicSensor::setDelay");
    if (ns < 0)
        return -EINVAL;

    switch (handle) {
        case ID_M:
			sensor_type = MagneticField;
			break;
        case ID_O:
			sensor_type = Orientation;
			break;
    }

    if (sensor_type == 0)
        return -EINVAL;

    return set_delay(sensor_type, ns/1000000);	//convert ns to ms
}

int MemsicSensor::set_delay(uint32_t type, int64_t ns)
{
    if (!ioctl(dev_fd, ECOMPASS_IOC_SET_DELAY, &ns)) {
        return -errno;
    } 

    ALOGE("MemsicSensor::set_delay done");
    return 0;
} 

int MemsicSensor::readEvents(sensors_event_t* data, int count)
{
    if (count < 1)
        return -EINVAL;

    ssize_t n = mInputReader.fill(data_fd);
    if (n < 0)
        return n;

	ALOGE("mInputReader:fd:%d %d\n",data_fd,n);
    int numEventReceived = 0;
    input_event const* event;

    while (count && mInputReader.readEvent(&event)) {
        int type = event->type;
        if (type == EV_REL || type == EV_ABS) {
            processEvent(event->code, event->value);
            mInputReader.next();
        } else if (type == EV_SYN) {
            int64_t time = timevalToNano(event->time);
            for (int j=0 ; count && mPendingMask && j<numSensors ; j++) {
                if (mPendingMask & (1<<j)) {
                    mPendingMask &= ~(1<<j);
                    mPendingEvents[j].timestamp = time;
                    if (mEnabled & (1<<j)) {
                        *data++ = mPendingEvents[j];
                        count--;
                        numEventReceived++;
                    }
                }
            }
            if (!mPendingMask) {
                mInputReader.next();
            }
        } else {
            ALOGE("MemsicSensor: unknown event (type=%d, code=%d)",
                    type, event->code);
            mInputReader.next();
        }
    }
    ALOGE(" readEvent:%d\n",numEventReceived);
    return numEventReceived;
}

void MemsicSensor::processEvent(int code, int value)
{
    switch (code) {
	    ALOGE("MemsicSensor::process event value = %d\n",value);
	    /*
        case EVENT_TYPE_ACCEL_X:
            mPendingMask |= 1<<Accelerometer;
            mPendingEvents[Accelerometer].acceleration.x = value * CONVERT_A;
            break;
        case EVENT_TYPE_ACCEL_Y:
            mPendingMask |= 1<<Accelerometer;
            mPendingEvents[Accelerometer].acceleration.y = value * CONVERT_A;
            break;
        case EVENT_TYPE_ACCEL_Z:
            mPendingMask |= 1<<Accelerometer;
            mPendingEvents[Accelerometer].acceleration.z = value * CONVERT_A;
            break;
	    */
        case EVENT_TYPE_MAGV_X:
            mPendingMask |= 1 << MagneticField;
            mPendingEvents[MagneticField].magnetic.x = value * CONVERT_M;
            break;
        case EVENT_TYPE_MAGV_Y:
            mPendingMask |= 1 << MagneticField;
            mPendingEvents[MagneticField].magnetic.y = value * CONVERT_M;
            break;
        case EVENT_TYPE_MAGV_Z:
            mPendingMask |= 1 << MagneticField;
            mPendingEvents[MagneticField].magnetic.z = value * CONVERT_M;
            break;

        case EVENT_TYPE_YAW:
            mPendingMask |= 1 << Orientation;
            mPendingEvents[Orientation].orientation.azimuth = value * CONVERT_O;
            break;
        case EVENT_TYPE_PITCH:
            mPendingMask |= 1 << Orientation;
            mPendingEvents[Orientation].orientation.pitch = value * CONVERT_O;
            break;
        case EVENT_TYPE_ROLL:
            mPendingMask |= 1 << Orientation;
            mPendingEvents[Orientation].orientation.roll = value * CONVERT_O;
            break;
        case EVENT_TYPE_ORIENT_STATUS:
            uint8_t status = uint8_t(value & SENSOR_STATE_MASK);
            if (status == 4)
                status = 0;
            mPendingMask |= 1 << Orientation;
            mPendingEvents[Orientation].orientation.status = status;
            break;
    }
}

bool MemsicSensor::isEnabled(int32_t handle) {
	return (0 != (mEnabled)) ? true : false;
}
