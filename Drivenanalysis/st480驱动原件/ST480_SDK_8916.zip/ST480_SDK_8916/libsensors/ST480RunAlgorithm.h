/*******************************************************************************
*  Copyright (C) 2014 Senodia
*
*  Copyright Statement:
*  ------------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Senodia Inc.
*  ------------------------
*
*  FileName: RunAlgorithm.h
*  Author : Tori Xu <xuezhi_xu@senodia.com,tori.xz.xu@gmail.com>
*  Reversion : V1.0.0
*******************************************************************************/

#ifndef RUN_ALGORITHM_H
#define RUN_ALGORITHM_H
extern "C"{
typedef struct {
     float  mag_x,
            mag_y,
            mag_z;
}_st480;

int st480_run_library(_st480 st480);
void get_magnetic_offset(float offset[3]);
void get_magnetic_values(float values[3]);
void get_calilevel_value(int *level);
}
#endif
